No column level expectations are in this suite. Feel free to add some here. They all begin with `batch.expect_column_...`.
