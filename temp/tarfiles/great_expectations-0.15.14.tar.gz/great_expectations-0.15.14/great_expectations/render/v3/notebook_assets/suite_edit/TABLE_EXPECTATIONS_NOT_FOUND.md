No table level expectations are in this suite. Feel free to add some here.
{% if batch_request %}
They all begin with `validator.expect_table_...`.
{% endif %}
