### Column Expectation(s)
